package com.example.bitfit

data class DisplayFood(
    val name: String?,
    val calories: Long?
) : java.io.Serializable